// Ponte nativa do Meu Treino. Entra so na versao do app (scripts/sync-web.js), antes dos scripts
// do index.html, e troca recursos do navegador pelos do celular. Fora do app nao faz nada.
(function () {
  'use strict';
  var C = window.Capacitor;
  if (!C || typeof C.isNativePlatform !== 'function' || !C.isNativePlatform()) return;
  var P = C.Plugins || {};
  window.FS_NATIVO = true;
  window.FS_PLATAFORMA = (C.getPlatform && C.getPlatform()) || '';

  // Sem service worker: o HTML ja vem dentro do pacote.
  try {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.register = function () {
        return Promise.resolve({ update: function () {}, unregister: function () { return Promise.resolve(true); } });
      };
    }
  } catch (e) {}

  // O app ja esta instalado: esconde as dicas "abra no Chrome" e "instale na tela de inicio".
  try { Object.defineProperty(navigator, 'standalone', { get: function () { return true; } }); } catch (e) {}

  // Vibracao
  try {
    navigator.vibrate = function (padrao) {
      try {
        var H = P.Haptics; if (!H) return false;
        var ms = Array.isArray(padrao) ? padrao.reduce(function (a, b) { return a + (Number(b) || 0); }, 0) : (Number(padrao) || 0);
        if (ms >= 150) H.notification({ type: 'SUCCESS' });
        else H.impact({ style: ms >= 50 ? 'MEDIUM' : 'LIGHT' });
        return true;
      } catch (e2) { return false; }
    };
  } catch (e) {}

  // Notification da web vira notificacao local
  var LN = P.LocalNotifications;
  var _perm = 'default';
  function _idDe(tag) {
    var h = 0, s = String(tag || Date.now());
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return Math.abs(h) % 2000000000;
  }
  function NotifNativa(titulo, opts) {
    opts = opts || {};
    // O lembrete do dia ja e agendado abaixo; dispara-lo agora duplicaria o aviso com o app aberto.
    if (opts.tag === 'treino-hoje') return;
    try {
      if (LN) LN.schedule({ notifications: [{ id: _idDe(opts.tag || titulo), title: String(titulo || ''), body: String(opts.body || ''),
        schedule: { at: new Date(Date.now() + 500) } }] });
    } catch (e) {}
  }
  Object.defineProperty(NotifNativa, 'permission', { get: function () { return _perm; } });
  NotifNativa.requestPermission = function () {
    if (!LN) return Promise.resolve('denied');
    return LN.requestPermissions().then(function (r) {
      _perm = (r && r.display === 'granted') ? 'granted' : 'denied';
      if (_perm === 'granted') setTimeout(agendarLembretes, 300);
      return _perm;
    }).catch(function () { _perm = 'denied'; return _perm; });
  };
  if (LN) {
    try {
      LN.checkPermissions().then(function (r) {
        _perm = (r && r.display === 'granted') ? 'granted' : (r && r.display === 'denied' ? 'denied' : 'default');
      });
    } catch (e) {}
  }
  try { window.Notification = NotifNativa; } catch (e) {}

  // Lembrete agendado as 7h30 nos dias com treino dos proximos 7 dias
  var DIAS = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB'];
  var BASE_ID = 7300;
  function agendarLembretes() {
    try {
      if (!LN || _perm !== 'granted') return;
      var ligado = false;
      try { ligado = localStorage.getItem('notif_enabled') === '1'; } catch (e) {}
      var ids = [];
      for (var k = 0; k < 7; k++) ids.push({ id: BASE_ID + k });
      LN.cancel({ notifications: ids }).catch(function () {}).then(function () {
        if (!ligado) return;
        var t = window._treino, st = window._st;
        if (!t || !t.dias) return;
        var nome = '';
        try { nome = (typeof window.firstName === 'function' && st) ? window.firstName(st.n) : ''; } catch (e) {}
        var lista = [];
        for (var d = 0; d < 7; d++) {
          var quando = new Date();
          quando.setDate(quando.getDate() + d);
          quando.setHours(7, 30, 0, 0);
          if (quando.getTime() <= Date.now()) continue;
          if (!t.dias[DIAS[quando.getDay()]]) continue;
          lista.push({ id: BASE_ID + d, title: '🏋️ Hoje é dia de treino!',
            body: 'Bora lá' + (nome ? (', ' + nome) : '') + '! Seu treino de hoje está te esperando.',
            schedule: { at: quando, allowWhileIdle: true } });
        }
        if (lista.length) LN.schedule({ notifications: lista });
      });
    } catch (e) {}
  }
  window.fsAgendarLembretes = agendarLembretes;
  window.addEventListener('load', function () { setTimeout(agendarLembretes, 4000); });
  try { if (P.App) P.App.addListener('appStateChange', function (s) { if (s && s.isActive) setTimeout(agendarLembretes, 2000); }); } catch (e) {}
  try {
    var _set = Storage.prototype.setItem;
    Storage.prototype.setItem = function (k) {
      var r = _set.apply(this, arguments);
      if (k === 'notif_enabled') setTimeout(agendarLembretes, 300);
      return r;
    };
  } catch (e) {}

  // Compartilhar imagem pela bandeja do sistema (a WebView nao tem Web Share com arquivo)
  function _base64(blob) {
    return new Promise(function (ok, erro) {
      var r = new FileReader();
      r.onload = function () { ok(String(r.result).split(',')[1]); };
      r.onerror = erro;
      r.readAsDataURL(blob);
    });
  }
  if (P.Share && P.Filesystem) {
    try {
      navigator.canShare = function (d) { return !!(d && d.files && d.files.length); };
      navigator.share = function (d) {
        var arq = d.files[0];
        return _base64(arq).then(function (dados) {
          return P.Filesystem.writeFile({ path: arq.name, data: dados, directory: 'CACHE' });
        }).then(function (res) {
          return P.Share.share({ title: d.title || 'Meu Treino', text: [d.text, d.url].filter(Boolean).join(' '), files: [res.uri], dialogTitle: 'Compartilhar treino' });
        });
      };
    } catch (e) {}
  }

  // Links externos no navegador do sistema
  function externo(url) {
    try { var u = new URL(url, location.href); return /^https?:$/.test(u.protocol) && u.host !== location.host; } catch (e) { return false; }
  }
  function abrirFora(url) {
    try {
      if (/^(tel|mailto|whatsapp|sms):/i.test(url)) { location.href = url; return true; }
      if (P.Browser && externo(url)) { P.Browser.open({ url: url }); return true; }
    } catch (e) {}
    return false;
  }
  var _open = window.open;
  window.open = function (url) {
    if (url && abrirFora(String(url))) return null;
    return _open ? _open.apply(window, arguments) : null;
  };
  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if ((a.target === '_blank' || externo(href) || /^(whatsapp|tel|mailto|sms):/i.test(href)) && abrirFora(a.href || href)) ev.preventDefault();
  }, true);

  // Botao voltar do Android: fecha o video; senao, minimiza
  try {
    if (P.App) P.App.addListener('backButton', function (e) {
      var video = document.querySelector('#modal-video.open');
      if (video && typeof window.fecharVideo === 'function') { window.fecharVideo(); return; }
      if (e && e.canGoBack) history.back(); else P.App.minimizeApp();
    });
  } catch (e) {}

  // Atualizacao remota: baixa em segundo plano e so troca o HTML quando o app abre do zero ou volta
  // depois de 1 hora, para nunca recarregar no meio de um treino. Sem notifyAppReady o plugin volta
  // sozinho para a versao anterior.
  var MANIFESTO = 'https://coachfiletsep-dev.github.io/app-aluno-atualizacoes/manifest.json';
  var ESPERA_MS = 60 * 60 * 1000;
  var U = P.CapacitorUpdater;
  var _baixando = false;
  function _ler(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function _gravar(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function aplicarPendente() {
    var id = _ler('fsOtaPendente');
    if (!id) return Promise.resolve(false);
    _gravar('fsOtaPendente', null);
    _gravar('fsOtaTentada', _ler('fsOtaPendenteVersao'));
    return U.set({ id: id }).then(function () { return true; }).catch(function () { return false; });
  }
  // Se a versao tentada nao ficou ativa, o plugin voltou atras: nao baixa essa versao de novo.
  function conferirTentativa() {
    var tentada = _ler('fsOtaTentada');
    if (!tentada) return Promise.resolve();
    return U.current().then(function (r) {
      if (!r.bundle || r.bundle.version !== tentada) _gravar('fsOtaRecusada', tentada);
      _gravar('fsOtaTentada', null);
    }).catch(function () {});
  }
  function procurarAtualizacao() {
    if (_baixando) return;
    _baixando = true;
    Promise.all([
      fetch(MANIFESTO + '?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error('manifesto'); return r.json(); }),
      U.current(),
      P.App.getInfo()
    ]).then(function (res) {
      var m = res[0], atual = res[1].bundle && res[1].bundle.version;
      if (!m || !m.version || !m.url || !m.sha256 || m.version === atual) return;
      if (m.version === _ler('fsOtaRecusada')) return;
      if (Number(res[2].build) < Number(m.nativoMinimo || 0)) return;
      return U.download({ url: m.url, version: m.version, checksum: m.sha256 }).then(function (b) {
        _gravar('fsOtaPendenteVersao', m.version);
        _gravar('fsOtaPendente', b.id);
      });
    }).catch(function () {}).then(function () { _baixando = false; });
  }
  if (U && P.App) {
    window.addEventListener('load', function () {
      try { U.notifyAppReady(); } catch (e) {}
      conferirTentativa().then(aplicarPendente).then(function (trocou) { if (!trocou) setTimeout(procurarAtualizacao, 8000); });
    });
    var _saiuEm = 0;
    P.App.addListener('appStateChange', function (s) {
      if (!s || !s.isActive) { _saiuEm = Date.now(); return; }
      if (!_saiuEm || Date.now() - _saiuEm < ESPERA_MS) return;
      if (window._circState) return;
      aplicarPendente().then(function (trocou) { if (!trocou) procurarAtualizacao(); });
    });
  }

  // Consentimento para dados de saude. A decisao fica no aparelho e e registrada no servidor.
  // Quem recusa ve e registra o treino, sem questionarios de saude, desconforto e ciclo.
  var CONSENT_VERSAO = '2';
  var POLITICA_URL = '';
  function _decisaoConsent() {
    var d = (_ler('fsConsentSaude') || '').split('|');
    return d[0] === CONSENT_VERSAO ? d[1] : '';
  }
  function enviarConsentimento() {
    var p = _ler('fsConsentEnviar');
    if (!p || !window._st || !window._st.s || typeof window.gp !== 'function') return;
    var d = p.split('|');
    window.gp({ registrarConsentimento: true, spreadsheetId: window._st.s, alunoNome: window._st.n,
      versao: d[0], decisao: d[1], dataAparelho: d[2], plataforma: window.FS_PLATAFORMA })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.sucesso) _gravar('fsConsentEnviar', null); })
      .catch(function () {});
  }
  function decidirConsentimento(decisao) {
    var valor = CONSENT_VERSAO + '|' + decisao + '|' + new Date().toISOString();
    _gravar('fsConsentSaude', valor);
    _gravar('fsConsentEnviar', valor);
    aplicarRecusa();
    enviarConsentimento();
  }
  function aplicarRecusa() {
    if (_decisaoConsent() !== 'recusado' || document.getElementById('fs-sem-saude')) return;
    var st = document.createElement('style');
    st.id = 'fs-sem-saude';
    st.textContent = '.desc-btn{display:none!important}';
    document.head.appendChild(st);
    var abrirPre = window.abrirPre, abrirPos = window.abrirPosModal;
    window.abrirPre = function () { var r = abrirPre.apply(this, arguments); window.pularPre(); return r; };
    window.abrirPosModal = function () {
      var r = abrirPos.apply(this, arguments);
      var m = document.getElementById('modal-pos');
      if (m && m.classList.contains('open')) window.pularPos();
      return r;
    };
    window._cicloAtivo = function () { return false; };
    window.abrirCicloTipo = function () {};
    window.cicloAutoShow = function () {};
  }
  function mostrarConsentimento() {
    aplicarRecusa();
    setTimeout(enviarConsentimento, 5000);
    window.addEventListener('online', enviarConsentimento);
    if (_decisaoConsent()) return;
    var ov = document.createElement('div');
    ov.id = 'fs-consentimento';
    ov.setAttribute('role', 'dialog');
    ov.setAttribute('aria-modal', 'true');
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:#111814;color:#F2F5F3;overflow:auto;padding:32px 20px;font:16px/1.5 system-ui,sans-serif';
    ov.innerHTML = '<div style="max-width:480px;margin:0 auto">' +
      '<h1 style="font-size:24px;line-height:1.25;margin:0 0 16px">Seus dados de treino e saúde</h1>' +
      '<p style="margin:0 0 12px">Para acompanhar seu treino, o app e seu treinador usam dados como dor, sono, fadiga, frequência cardíaca, condições clínicas e, se você preencher, ciclo menstrual.</p>' +
      '<p style="margin:0 0 12px">Esses dados são usados para ajustar seu treino e gerar relatórios. Parte deles é processada por serviços parceiros, como Google e Anthropic (inteligência artificial), inclusive fora do Brasil. Na IA, seu nome é trocado por um código.</p>' +
      '<p style="margin:0 0 12px">Se não concordar, você ainda vê e registra o treino, sem os questionários de saúde e de ciclo menstrual.</p>' +
      '<p style="margin:0 0 20px">Para maiores de 18 anos. Você pode mudar de ideia ou pedir a exclusão dos dados por fswellnesspro@gmail.com ou WhatsApp (11) 99299-0637.</p>' +
      (POLITICA_URL ? '<p style="margin:0 0 20px"><a href="' + POLITICA_URL + '" target="_blank" style="color:#5FD3A8">Ler a política de privacidade</a></p>' : '') +
      '<button id="fs-consent-sim" style="display:block;width:100%;min-height:48px;margin-bottom:12px;border:0;border-radius:12px;background:#1D9E75;color:#fff;font:600 16px system-ui,sans-serif">Concordo e continuar</button>' +
      '<button id="fs-consent-nao" style="display:block;width:100%;min-height:48px;border:1px solid #4A5650;border-radius:12px;background:transparent;color:#F2F5F3;font:600 16px system-ui,sans-serif">Não concordo</button>' +
      '</div>';
    document.body.appendChild(ov);
    document.getElementById('fs-consent-sim').onclick = function () { decidirConsentimento('aceito'); ov.remove(); };
    document.getElementById('fs-consent-nao').onclick = function () { decidirConsentimento('recusado'); ov.remove(); };
  }
  document.addEventListener('DOMContentLoaded', mostrarConsentimento);

  // Tela de codigo: aceita o link inteiro que o aluno recebe, alem do codigo sozinho
  function extrairCodigo(texto) {
    var t = String(texto || '').replace(/\s+/g, '');
    var m = t.match(/(?:^|[?&])aluno=([^&#]+)/);
    if (m) t = m[1];
    if (t.indexOf('%') > -1) { try { t = decodeURIComponent(t); } catch (e) {} }
    return t;
  }
  document.addEventListener('DOMContentLoaded', function () {
    var original = window.entrar;
    if (typeof original !== 'function') return;
    window.entrar = function () {
      var campo = document.getElementById('auth-token');
      if (campo) campo.value = extrairCodigo(campo.value);
      return original.apply(this, arguments);
    };
  });
})();
